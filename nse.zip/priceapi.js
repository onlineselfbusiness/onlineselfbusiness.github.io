
if(window.self !== window.top) {
    
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.dir(request)
        fetchScriptHistoryData(sendResponse, request.scriptName)
        /*if(request.type === 'iChartSentiment') {
            
            return true
        } else if(request.type === 'iChartScreener') {
            fetchIchartScreenerEOD(sendResponse)
            return true
        }*/
        return true
    })

    function fetchScriptHistoryData(sendResponse, scriptName) {
        fetch('https://priceapi.moneycontrol.com/techCharts/history?symbol=9&resolution=1D&from=1640995200&to=1657929600')
        .then(res => {
            if(res.status!==200)
            {
                sendResponse('')
            }
            return res.json()
        })
        .then(json => {
            console.dir(json)
            sendResponse(json)
        })
        .catch(err => {
            console.error(err)
            sendResponse('')
        })
    }

    function fetchIchartScreenerEOD(sendResponse) {
        fetch('https://main.icharts.in/includes/screener/EODScan.php?export=1')
        .then(res => {
            if(res.status!==200)
            {
                sendResponse('')
            }
            return res.text()
        })
        .then(csv => {
            console.dir(csv)
            sendResponse(csv)
        })
        .catch(err => {
            console.error(err)
            sendResponse('')
        })
    }
}
