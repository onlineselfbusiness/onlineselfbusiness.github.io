
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({
        name: "NSE data download"
    });
});

chrome.declarativeNetRequest.getDynamicRules(function(rules) {
    var ruleIdx = 0;
    var existingRules = [];
    for (var i=0;i<rules.length;i++) {
        ruleIdx = rules[i].id;
        existingRules.push(rules[i].id);
    }
    ruleIdx++;
    chrome.declarativeNetRequest.updateDynamicRules({
    addRules: 
        [
            {
                action: {
                    type: "modifyHeaders",
                    /*requestHeaders: [{header: "referrer", operation: "set", value: "https://www1.nseindia.com/products/content/derivatives/equities/historical_fo.htm"},
                        {header: "sec-fetch-site", operation: "set", value: 'same-origin'},
                        {header: "x-requested-with", operation: "set", value: 'XMLHttpRequest'},
                        {header: "sec-ch-ua", operation: "set", value: '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"'},
                        {header: "sec-ch-ua-mobile", operation: "set", value: '?0'},
                        {header: "sec-ch-ua-platform", operation: "set", value: '"Windows"'}],
                    */
                    responseHeaders: [{header: "x-frame-options", operation: "remove"}]
                },
                //condition: {"regexFilter": "^https://sports\.yahoo\.com(.*)$", "resourceTypes": ["main_frame"]},
                condition: { urlFilter: "nseindia.com", resourceTypes: ["main_frame", "sub_frame", "script", "xmlhttprequest"] },
                id: ruleIdx,
                priority: 1
            },
        
        ],
    removeRuleIds: existingRules
    });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'loading' && (tab.url.indexOf("localhost/") > -1 || tab.url.indexOf("onlineselfbusiness.github.io") > -1)) {
        chrome.scripting.insertCSS({
            target: { tabId: tabId },
            files: ["./foreground_styles.css"]
        })
        .then(() => {
            chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ["./js/jquery.js"]
            })
            .then(() => {
                chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    files: ["./foreground.js"]
                })
                .then(() => {
                });
            });
        })
        .catch(err => console.log(err));
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'OptionChain') {
        downloadOptionChain(sendResponse, request.indexName, 1)
        return true
    } else if (request.type === 'WorldMarket') {
        new Promise(async (res, rej) => {
            let promiseAllRes = await Promise.allSettled([fetchWorldMarket(), fetchSGXNifty()])
            sendResponse(promiseAllRes)
            res()
        })
        return true
    } else if (request.type === 'OptionHistory') {
        let optionType = request.data.optionType
        let strikePrice = request.data.strikePrice
        let expiryDate = request.data.expiryDate
        let symbol = request.data.symbol
        fetchOptionHistory(sendResponse, optionType, strikePrice, expiryDate, symbol, 1)
        return true
    } else if(request.type === 'ScriptHistory') {
        new Promise(async (res, rej) => {
            let v = await fetchCookie()
            //console.dir(v)
            downloadScriptHistoryWrapper(sendResponse, request.scriptName)
            res()
        })
        return true
    } else if(request.type === 'OptionAllHistory') {
        /*
        new Promise(async (res, rej) => {
            let v = await fetchCookieFromOldWebsite()  // fetchCookie()
            downloadOptionAllHistoryWrapper(sendResponse, request.expiryDate, request.sprikePrices)
            res()
        })
        */
        chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
            if(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {type : 'OptionAllHistory', expiryDate: request.expiryDate, sprikePrices: request.sprikePrices }, function(response) {
                    //console.log(response);
                    sendResponse(response)
                });
            } else {
                sendResponse('')
            }
        }); 
        return true
    } else if(request.type === 'ETDatepickerReq') {
        fetchResultCalendar(sendResponse, request.startDate)
        return true
    } else if(request.type === 'MoneyControlRCReq') {
        fetchMoneyControlRC(sendResponse)
        return true
    } else if(request.type === 'EconomicCalendar') {
        fetchEconomicCalendar(sendResponse)
        return true
    } else if(request.type === 'ETDatepickerDaysReq') {
        new Promise(async (res, rej) => {
            var etArr = []
            var tDate = new Date()
            for(var i=0; i<request.days; i++) {
                etArr.push(fetchResultCalendarForDays(tDate.toISOString().split('T')[0]))
                tDate = new Date(tDate.getTime() + (24 * 60 * 60 * 1000))
            }
            let promiseAllRes = await Promise.allSettled(etArr)
            sendResponse(promiseAllRes)
            res()
        })
        return true
    } else if(request.type == 'MaxPainReq') {
        maxPainForAll(sendResponse)
        return true
    } else if(request.type == 'Nifty50Stocks') {
        nifty50LiveStocks(sendResponse)
        return true
    } else if(request.type === 'OptionChainGraph') {
        new Promise(async (res, rej) => {
            let v = await fetchCookie()
            let vArr = request.value.split(',')
            let promiseAllRes = await Promise.allSettled([fetchOptionGraph(vArr[0]), fetchOptionGraph(vArr[1])])
            sendResponse(promiseAllRes)
            res()
        })
        return true
    } else if(request.type === 'GoogleGraph') {
        fetchGoogleGraph(sendResponse)
        return true
    } else if(request.type === 'iChartScreener') {
        //fetchIchartScreenerEOD(sendResponse)
        chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
            if(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {type : 'iChartScreener' }, function(response) {
                    //console.log(response);
                    sendResponse(response)
                });
            } else {
                sendResponse('')
            }
        }); 
        return true
    } else if(request.type === 'iChartSentiment') {
        //fetchIchartSentiment(sendResponse, request.scriptName)
        chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
            if(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {type : 'iChartSentiment', scriptName: request.scriptName }, function(response) {
                    //console.log(response);
                    sendResponse(response)
                });
            } else {
                sendResponse('')
            }
        });
        return true
    } else if(request.type === 'CashAndCarry') {
        fetchCashAndCarry(sendResponse)
        return true
    } else if(request.type === 'OpstraSD') {
        fetchOpstraStandardDerivative(sendResponse, request.scriptName)
        /*chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
            if(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {type : 'fetchOpstraSD', scriptName: request.scriptName }, function(response) {
                    console.log(response);
                    sendResponse(response)
                });
            }
        });*/

        return true
    } else if(request.type === 'PriceApi') {
        //fetchScriptHistoryData(sendResponse, request.scriptName)
        /*chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
            if(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {type : 'PriceApi', scriptName: request.scriptName }, function(response) {
                    console.log(response);
                    sendResponse(response)
                });
            }
        });*/ 

        new Promise(async (res, rej) => {
            downloadScriptHistoryFromPriceAPI(sendResponse, request.scriptName)
            res()
        })
        return true
    }else if(request.type === 'Margin') {
        fetchMargin(sendResponse, request.formData)
        return true
    }
});

function downloadOptionChain(sendResponse, symbol, tryIndex) {
    // https://www.nseindia.com/get-quotes/derivatives?symbol=NIFTY

    let url = "https://www.nseindia.com/api/option-chain-indices?symbol=" + symbol
    if(symbol != 'NIFTY' && symbol != 'BANKNIFTY') {
        url = "https://www.nseindia.com/api/option-chain-equities?symbol=" + symbol
    }

    fetch(url,
        {
            method: 'GET',
            cache: 'no-cache',
            mode: 'cors',
            headers: {
                'Referer': 'https://www.nseindia.com/api/option-chain',
                "X-Requested-With": "XMLHttpRequest",
                'accept-encoding': 'gzip, deflate, br',
                "Accept": "*/*"
            },
            referrer: 'https://www.nseindia.com/api/option-chain',
    })
    .then(res => {
        if (res.status !== 200) {
            throw new Error(res.status)
        }
        return res.text()
    })
    .then(async r =>  {
        if(r === "{}" && tryIndex < 3) {
            let v = await fetchCookie()
            console.dir(v)
            downloadOptionChain(sendResponse, symbol, ++tryIndex)
        } else {
            sendResponse(r)
        }
    }).catch(async function (err) {
        console.dir(err);
        let v = await fetchCookie()
        console.dir(v)
        if(tryIndex < 3) {
            downloadOptionChain(sendResponse, symbol, ++tryIndex)
        } else {
            sendResponse('{}')
        }
    })
}

async function fetchCookieFromOldWebsite() {
    let promise = new Promise((resolve, reject) => {
        fetch("https://www1.nseindia.com/",
        {
            method: 'GET',
            cache: 'no-cache',
            mode: 'cors',
            headers: {
                "X-Requested-With": "XMLHttpRequest",
                'accept-encoding': 'gzip, deflate, br',
                "Accept": "*/*"
            },
        })
        .then(res => {
            if (res.status !== 200) {
                throw new Error(res.status)
            }
            return res.text()
        })
        .then(r => {
            //console.dir(r)
            resolve('good')
        }).catch(function (err) {
            console.dir(err);
            resolve('bad')
        })
    })
    return promise
}

async function fetchCookie() {
    let promise = new Promise((resolve, reject) => {
        fetch("https://www.nseindia.com",
        {
            method: 'GET',
            cache: 'no-cache',
            mode: 'cors',
            headers: {
                "X-Requested-With": "XMLHttpRequest",
                'accept-encoding': 'gzip, deflate, br',
                "Accept": "*/*"
            },
        })
        .then(res => {
            if (res.status !== 200) {
                throw new Error(res.status)
            }
            return res.text()
        })
        .then(r => {
            //console.dir(r)
            resolve('good')
        }).catch(function (err) {
            console.dir(err);
            resolve('bad')
        })
    })
    return promise
}

function fetchWorldMarket() {
    let promise = new Promise((resolve, reject) => {
        fetch('https://sgxnifty.org/world-markets/').then(res => res.text())
        .then(html => {
            resolve(html)
        }).catch(err => {
            console.error(err)
            resolve('')
        })
    })
    return promise
}

function fetchSGXNifty() {
    let promise = new Promise((resolve, reject) => {
        fetch('https://sgxnifty.org/').then(res => res.text())
        .then(html => {
            resolve(html)
        }).catch(err => {
            console.error(err)
            resolve('')
        })
    })
    return promise
}

function fetchOptionHistory(sendResponse, optionType, strikePrice, expiryDate, symbol, tryIndex) {
    let to = new Date()
     to = to.toJSON().substr(0,10).split("-")
     to = to[2] + "-" + to[1] + "-" + to[0]
    
     let from = new Date()
     from.setMonth(from.getMonth() - 3)
     from = from.toJSON().substr(0,10).split("-")
     from = from[2] + "-" + from[1] + "-" + from[0]

     let instrumentType = 'OPTSTK'
     if(symbol == 'NIFTY' | symbol == 'BANKNIFTY') {
        instrumentType = 'OPTIDX'
     }
    
     let url = "https://www.nseindia.com/api/historical/fo/derivatives?&from="+from+"&to="+to+"&optionType="+optionType+"&strikePrice="+strikePrice
     +"&expiryDate="+expiryDate+"&instrumentType="+instrumentType+"&symbol=" + symbol
     //console.dir(url)
     fetch(url) 
         .then(res => {
            if (res.status !== 200) {
                throw new Error(res.status)
            }
            return res.json()
        })
         .then(async res => {
            sendResponse(res)
         })
         .catch(async e => {
             console.error(e)
             let v = await fetchCookie()
            console.dir(v)
            if(tryIndex < 3) {
                fetchOptionHistory(sendResponse, optionType, strikePrice, expiryDate, symbol, ++tryIndex)
            } else {
                sendResponse('{}')
            }
        }); 
}

function downloadScriptHistoryWrapper(sendResponse, scriptNames) {
    let promiseAll = new Promise(async(resolve, reject) => {
        let arr = scriptNames.split(',')
        let sPromises = []
        for(let i=0; i<arr.length; i++) {
            let script = arr[i]
            if(script == 'NIFTY' || script == 'BANKNIFTY') {
                sPromises.push(indexHistoricalData(script, 1))
                sPromises.push(indexHistoricalData(script, 2))
            } else {
                sPromises.push(downloadScriptHistory(script))
            }
        }
        let promiseAllRes = await Promise.allSettled(sPromises)
        sendResponse(promiseAllRes)
        resolve(promiseAllRes)
    })
    return promiseAll
}

function downloadScriptHistoryFromPriceAPI(sendResponse, scriptNames) {
    let promiseAll = new Promise(async(resolve, reject) => {
        let arr = scriptNames.split(',')
        let sPromises = []
        for(let i=0; i<arr.length; i++) {
            sPromises.push(fetchScriptHistoryDataFromPriceApi(arr[i]))
        }
        let promiseAllRes = await Promise.allSettled(sPromises)
        sendResponse(promiseAllRes)
        resolve(promiseAllRes)
    })
    return promiseAll
}

function downloadScriptHistory(scriptName) {
    let promise = new Promise((resolve, reject) => {
        let today = new Date()
        let todayDay = (today.getDate() < 10 ? '0' + today.getDate() :  today.getDate() );
        let todayMonth = (today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : (today.getMonth() + 1))
        let todayStr = todayDay+ '-' + todayMonth + '-' + today.getFullYear()
      
        let fromDay = new Date()
        fromDay.setDate(today.getDate() - 400)
        let fromDayDate = (fromDay.getDate() < 10 ? '0' + fromDay.getDate() :  fromDay.getDate() );
        let fromDayMonth = (fromDay.getMonth() < 9 ? '0' + (fromDay.getMonth() + 1) : (fromDay.getMonth() + 1))
        let fromDayStr = fromDayDate+ '-' + fromDayMonth + '-' + fromDay.getFullYear()
      
        fetch("https://www.nseindia.com/api/historical/cm/equity?symbol=" 
          + encodeURIComponent(scriptName) + "&series=[%22EQ%22]&from=" 
          + fromDayStr + "&to=" + todayStr + "&csv=true",
            {
                method: 'GET',
                cache: 'no-cache',
                mode: 'cors',
                headers: {
                    'Referer': 'https://www.nseindia.com/products/content/equities/equities/eq_security.htm',
                    "X-Requested-With": "XMLHttpRequest",
                    "Accept": "*/*"
                },
            }
        )
        .then(res => {
            if(res.status!==200)
            {
                throw new Error(res.status)
            }
            return res.text()
        })
        .then(res => {
            // "Date ","series ","OPEN ","HIGH ","LOW ","PREV. CLOSE ","ltp ","close ","vwap ","52W H ","52W L ","VOLUME ","VALUE ","No of trades "
            let scriptData = res.match(/[^\r\n]+/g);
            scriptData.splice(0, 1)
            let data = []
            scriptData.forEach(d => {
                d = d.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g);
                data.push(d.map(v => v.replace(/"/g, "")).map(v => v.replace(/,/g, "")))
            })
            let formattedData = []
            data.forEach((row, index) => {
                let d = []
                d.push(row[0])
                d.push(row[2])
                d.push(row[3])
                d.push(row[4])
                d.push(row[7])
                d.forEach((s, index, arr) => {
                    if (!isNaN(s)) {
                        arr[index] = parseFloat(s)
                    }
                })
                formattedData.push(d)
            })
            //data.slice(0, 300)
            //console.dir(formattedData)
            resolve({name: scriptName, data: formattedData})
        }).catch(function(err) {
            console.error(err)
            resolve({name: scriptName, data: []})
        });
    })
    return promise 
}

function indexHistoricalData(symbol, y) {
    let tSymbol = symbol
    if(symbol == 'NIFTY') {
        tSymbol = symbol + ' 50'
    } else if(symbol == 'BANKNIFTY') {
        tSymbol = 'NIFTY BANK'
    }
    let todayStr = ''
    let fromDayStr = ''
    if(y==2){
        let today = new Date()
        today.setDate(today.getDate() - 356)
        let todayDay = (today.getDate() < 10 ? '0' + today.getDate() :  today.getDate() )
        let todayMonth = (today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : (today.getMonth() + 1))
        todayStr = todayDay+ '-' + todayMonth + '-' + today.getFullYear()

        let fromDay = new Date()
        fromDay.setDate(today.getDate() - 355)
        let fromDayDate = (fromDay.getDate() < 10 ? '0' + fromDay.getDate() :  fromDay.getDate() );
        let fromDayMonth = (fromDay.getMonth() < 9 ? '0' + (fromDay.getMonth() + 1) : (fromDay.getMonth() + 1))
        fromDayStr = fromDayDate+ '-' + fromDayMonth + '-' + fromDay.getFullYear()
    } else {
        let today = new Date()
        let todayDay = (today.getDate() < 10 ? '0' + today.getDate() :  today.getDate() )
        let todayMonth = (today.getMonth() < 9 ? '0' + (today.getMonth() + 1) : (today.getMonth() + 1))
        todayStr = todayDay+ '-' + todayMonth + '-' + today.getFullYear()

        let fromDay = new Date()
        fromDay.setDate(today.getDate() - 355)
        let fromDayDate = (fromDay.getDate() < 10 ? '0' + fromDay.getDate() :  fromDay.getDate() );
        let fromDayMonth = (fromDay.getMonth() < 9 ? '0' + (fromDay.getMonth() + 1) : (fromDay.getMonth() + 1))
        fromDayStr = fromDayDate+ '-' + fromDayMonth + '-' + fromDay.getFullYear()
    }

    let promise = new Promise((resolve, reject) => {

    fetch(
        "https://www1.nseindia.com/products/dynaContent/equities/indices/historicalindices.jsp?indexType="+tSymbol+"&fromDate=" + fromDayStr + "&toDate=" + todayStr,
        {
            method: 'GET',
            cache: 'no-cache',
            mode: 'cors',
            headers: {
                'Referer': 'https://www1.nseindia.com',
                "X-Requested-With": "XMLHttpRequest",
                "Accept": "*/*"
            },
            referrer: 'https://www1.nseindia.com',
        }
    )
    .then(res => {
        if(res.status!==200)
        {
            throw new Error(res.status)
        }
        return res.text()
    })
    .then(html => {
        //console.dir(html)
        if(html.indexOf('csvContentDiv') > -1) {
            html = html.substring(html.indexOf('csvContentDiv'))
            html = html.substring(html.indexOf('>"') + 1, html.indexOf('</div>'))
            let dataArr = html.split(':')
            let data = []
            dataArr.forEach(function(d) {
                data.push(d.replace(/"/g, "").replace(/ /g, '').split(',').map(v => { 
                    if(isNaN(v)) {
                        return v
                    } else {
                        return parseFloat(v)
                    }
                }).slice(0,5))
            })
            data = data.slice(1)
            data.reverse()
            data = data.slice(1) // ["Date","Open","High","Low","Close","Shares Traded","Turnover (Rs. Cr)"]
            resolve({name: symbol, data: data})
        } else {
            resolve({name: symbol, data: []})
        }
    }).catch(function(err) {
        console.error(err)
        resolve({name: symbol, data: []})
    })
    })
    return promise
}

function fetchResultCalendar(sendResponse, startDate) {
    // Main Page : https://economictimes.indiatimes.com/markets/stocks/mcalendar.cms
    fetch("https://etfeedscache.indiatimes.com/ETService/getMarketCalendarByDate?pageno=1&pagesize=100&startdate="+startDate, {
    "headers": {
        "accept": "*/*",
        "accept-language": "en-US,en;q=0.9",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "script",
        "sec-fetch-mode": "no-cors",
        "sec-fetch-site": "same-site"
    },
    "referrer": "https://economictimes.indiatimes.com/",
    "body": null,
    "method": "GET",
    "mode": "cors",
    "credentials": "include"
    }).then(html => html.text())
    .then(json => {
        //console.dir(json)
        sendResponse(JSON.parse(json))
    }).catch(e => {
        console.error(e)
        sendResponse({})
    })
}
function fetchResultCalendarForDays(startDate) {

    let promise = new Promise((resolve, reject) => {
    // Main Page : https://economictimes.indiatimes.com/markets/stocks/mcalendar.cms
    fetch("https://etfeedscache.indiatimes.com/ETService/getMarketCalendarByDate?pageno=1&pagesize=100&startdate="+startDate, {
    "headers": {
        "accept": "*/*",
        "accept-language": "en-US,en;q=0.9",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"",
        "sec-ch-ua-mobile": "?0",
        "sec-fetch-dest": "script",
        "sec-fetch-mode": "no-cors",
        "sec-fetch-site": "same-site"
    },
    "referrer": "https://economictimes.indiatimes.com/",
    "body": null,
    "method": "GET",
    "mode": "cors",
    "credentials": "include"
    }).then(html => html.text())
    .then(json => {
        resolve(JSON.parse(json))
    }).catch(e => {
        console.error(e)
        resolve({})
    })
    })
    return promise
    
}
function maxPainForAll(sendResponse) {
    fetch("https://api.niftytrader.in/api/SA/PSymbolsList", {
        "referrer": "https://api.niftytrader.in/",
        "method": "GET",
        "mode": "cors",
    }).then(html => html.json())
    .then(json => {
        //console.dir(json)
        sendResponse(json)
    }).catch(e => {
        console.error(e)
        sendResponse({resultData: []})
    })
}

function nifty50LiveStocks(sendResponse) {
    fetch("https://api.niftytrader.in/api/Resources/nifty50Stock", {
        "referrer": "https://api.niftytrader.in/",
        "method": "GET",
        "mode": "cors",
    }).then(html => html.json())
    .then(json => {
        //console.dir(json)
        sendResponse(json)
    }).catch(e => {
        console.error(e)
        sendResponse({resultData: []})
    })
}

function fetchOptionGraph(index) {
    let promise = new Promise((resolve, reject) => {
        fetch("https://www.nseindia.com/api/chart-databyindex?index=" + index, {
        "referrer": "https://www.nseindia.com/",
        "method": "GET",
        "mode": "no-cors",
        }).then(html => html.json())
        .then(json => {
            //console.dir(json)
            resolve(json)
        }).catch(e => {
            console.error(e)
            resolve({})
        })
    })
    return promise
}

function fetchGoogleGraph(sendResponse) {
    let promise = new Promise((resolve, reject) => {
        fetch('https://www.google.com/search?q=Nikkei%20225').then(res => res.text())
        .then(html => {
            sendResponse(html)
            resolve(html)
        }).catch(err => {
            console.error(err)
            sendResponse('')
            resolve('')
        })
    })
    return promise
}

function fetchMoneyControlRC(sendResponse) {
    fetch('https://www.moneycontrol.com/markets/earnings/results-calendar/')
    .then(html => html.text())
    .then(html => {
        console.dir(html);
        sendResponse(html)
    }).catch(err => {
        console.error(err)
        sendResponse('')
    })
}

function fetchIchartScreenerEOD(sendResponse) {
    fetch('https://www.main.icharts.in/includes/screener/EODScan.php?export=1')
    .then(res => {
        if(res.status!==200)
        {
            sendResponse('')
        }
        return res.text()
    })
    .then(csv => {
        console.dir(csv)
        sendResponse(csv)
    })
    .catch(err => {
        console.error(err)
        sendResponse('')
    })
}

function fetchIchartSentiment(sendResponse, scriptName) {
    fetch('https://www.main.icharts.in/jcharts/StockGlance_eod.php?symbol='+ scriptName+ '/sdf')
    .then(res => {
        if(res.status!==200)
        {
            sendResponse('')
            return;
        }
        return res.text()
    })
    .then(csv => {
        console.dir(csv)
        sendResponse(csv)
    })
    .catch(err => {
        console.error(err)
        sendResponse('')
    })
}

function fetchCashAndCarry(sendResponse) {
    fetch('https://www.moneycontrol.com/stocks/fno/marketstats/arbitrage/futures-spot-near.html')
    .then(res => {
        if(res.status!==200)
        {
            sendResponse('')
        }
        return res.text()
    })
    .then(html => {
        console.dir(html)
        sendResponse(html)
    })
    .catch(err => {
        console.error(err)
        sendResponse('')
    })
}

// TODO: not working because of referrer missing in the request
function fetchOpstraStandardDerivative(sendResponse, scriptNameWithExpiry) {
    fetch('https://opstra.definedge.com/api/free/strategybuilder/strikes/' + scriptNameWithExpiry, 
    {referer: "https://opstra.definedge.com/strategy-builder",
    referrerPolicy: "strict-origin-when-cross-origin"})
    .then(res => {
        if(res.status!==200)
        {
            sendResponse('')
        }
        return res.json()
    })
    .then(json => {
        console.dir(json)
        sendResponse(json)
    })
    .catch(err => {
        console.error(err)
        sendResponse('')
    })
}

function fetchScriptHistoryDataFromPriceApi(scriptName) {
    let promise = new Promise((resolve, reject) => {
        let f = new Date().toDateString().split(' ')
        f = (new Date((parseInt(f[3])-2) + '-' + 'Jan-01').getTime() + '').substring(0, 10)
        let t = (new Date().getTime() + '').substring(0, 10)
        let sn = scriptName
        if(scriptName == 'NIFTY') {
            sn = 9
        }else if(scriptName == 'BANKNIFTY') {
            sn = 23
        }
    //https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=APOLLOTYRE&resolution=1D&from=1623839641&to=1657967701
    //https://priceapi.moneycontrol.com/techCharts/history?symbol=9&resolution=1D&from=1623839641&to=1657967701
        fetch('https://priceapi.moneycontrol.com/techCharts/history?symbol=' + sn + '&resolution=1D&from=' + f +'&to=' + t)
        .then(res => {
            if(res.status!==200)
            {
                resolve({name: scriptName, data: {}})
            }
            return res.json()
        })
        .then(json => {
            console.dir(json)
            resolve({name: scriptName, data: json})
        })
        .catch(err => {
            console.error(err)
            resolve({name: scriptName, data: {}})
        })
    })
    return promise 
}

function downloadOptionAllHistoryWrapper(sendResponse, expiryDate, strikePrices) {
    let promiseAll = new Promise(async(resolve, reject) => {

        let ed = expiryDate
        let to = new Date(ed)
        to = to.toLocaleDateString().split('/')
        to = (to[1].length == 1 ? '0' + to[1] : to[1]) + '-' + (to[0].length == 1 ? '0' + to[0] : to[0]) + '-' + to[2]

        let from = new Date('01' + ed.substr(2))
        from.setMonth(from.getMonth() - 2)
        from.setDate(from.getDate() - 1)
        while (true) {
            if (from.toDateString().indexOf('Thu') > -1) {
                break;
            }
            from.setDate(from.getDate() - 1)
        }
        from = new Date(from)
        from = from.toLocaleDateString().split('/')
        from = (from[1].length == 1 ? '0' + from[1] : from[1]) + '-' + (from[0].length == 1 ? '0' + from[0] : from[0]) + '-' + from[2]
        let arr = strikePrices.split(',')
        let sPromises = []
        for(let i=0; i<1; i++) {
            //sPromises.push(optionAllHistoryForStrikePriceFromOldWebsite(expiryDate, arr[i], from, to, 'PE'))
            sPromises.push(optionAllHistoryForStrikePriceFromOldWebsite(expiryDate, arr[i], from, to, 'CE'))
        }
        let promiseAllRes = await Promise.allSettled(sPromises)
        sendResponse(promiseAllRes)
        resolve(promiseAllRes)
    })
    return promiseAll
}

function optionAllHistoryForStrikePriceFromOldWebsite(ed, sp, from, to, optionType) {
    sp = sp.replace('.00','')
    let edArr = ed.split('-')
    let d = new Date(ed)
    let m = (d.getMonth() + 1) + ''
    let led = edArr[0] + '-' + ((m.length == 1) ? ('0' + m) : m ) + '-' + edArr[2]
    ed = led
    // https://www1.nseindia.com/products/dynaContent/common/productsSymbolMapping.jsp?instrumentType=OPTIDX&symbol=NIFTY&expiryDate=25-01-2023&optionType=CE&strikePrice=18000&dateRange=12month&fromDate=&toDate=&segmentLink=9&symbolCount=

    //let url = 'https://www.nseindia.com/api/historical/fo/derivatives?&from=' + from + '&to=' + to + '&optionType=' + optionType + '&strikePrice=' + sp + '&expiryDate=' + ed + '&instrumentType=OPTIDX&symbol=NIFTY'
    let url = 'https://www1.nseindia.com/products/dynaContent/common/productsSymbolMapping.jsp?instrumentType=OPTIDX&symbol=NIFTY&expiryDate=' + ed + '&optionType=' + optionType + '&strikePrice=' + sp + '&dateRange=12month&fromDate=&toDate=&segmentLink=9&symbolCount='
    let promise = new Promise((resolve, reject) => {
        fetch(url,
            {
                "headers": {
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"",
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": "\"Windows\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin"
                },
                "referrer": "https://www1.nseindia.com/products/content/derivatives/equities/historical_fo.htm",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": null,
                "method": "GET",
                "mode": "cors",
                "credentials": "include"
            }).then(res => {
                if (res.status !== 200) {
                    throw new Error(res.status)
                }
                return res.text()
            }).then(html => {

                console.dir(html)

                resolve({ed: ed, sp: sp, data: [], optionType: optionType})
            }).catch(function (err) {
                resolve({ed: ed, sp: sp,  data: [], optionType: optionType})
            });
        });
    return promise
}

function optionAllHistoryForStrikePrice(ed, sp, from, to, optionType) {
    let url = 'https://www.nseindia.com/api/historical/fo/derivatives?&from=' + from + '&to=' + to + '&optionType=' + optionType + '&strikePrice=' + sp + '&expiryDate=' + ed + '&instrumentType=OPTIDX&symbol=NIFTY'
    let promise = new Promise((resolve, reject) => {
        fetch(url,
            {
                "headers": {
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"",
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": "\"Windows\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin"
                },
                "referrer": "https://www.nseindia.com/get-quotes/derivatives?symbol=NIFTY",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": null,
                "method": "GET",
                "mode": "cors",
                "credentials": "include"
            }).then(res => {
                if (res.status !== 200) {
                    throw new Error(res.status)
                }
                return res.json()
            }).then(json => {
                resolve({ed: ed, sp: sp, data: json, optionType: optionType})
            }).catch(function (err) {
                resolve({ed: ed, sp: sp,  data: [], optionType: optionType})
            });
        });
    return promise
}

async function fetchEconomicCalendar(sendResponse) {
    let sPromises = []
    let durationArr = ['TW','NW']
    let impactArr = ['3', '2', '1']
    for(let i=0;i<durationArr.length;i++) {
        for(let j=0; j<impactArr.length; j++) {
            let promise = new Promise((resolve, reject) => {
                fetch('https://www.moneycontrol.com/economic-widget?duration=' + durationArr[i] + '&startDate=&endDate=&impact='+impactArr[j]+'&country=&deviceType=web&classic=true').then(res => res.text())
                .then(html => {
                    resolve(html)
                }).catch(err => {
                    console.error(err)
                    resolve('')
                })
            })
            sPromises.push(promise)
        }
    }
    let promiseAllRes = await Promise.allSettled(sPromises)
    sendResponse(promiseAllRes)
    return promiseAllRes
}

function fetchOpstraStandardDerivative(sendResponse, scriptNameWithExpiry) {
    fetch('https://opstra.definedge.com/api/free/strategybuilder/strikes/' + scriptNameWithExpiry, {
        "headers": {
          "accept": "application/json, text/plain, */*",
          "accept-language": "en-US,en;q=0.9",
          "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"",
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": "\"Windows\"",
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "same-origin"
        },
        "referrer": "https://opstra.definedge.com/strategy-builder",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": null,
        "method": "GET",
        "mode": "cors",
        "credentials": "include"
      })
    .then(res => {
        if(res.status!==200)
        {
            sendResponse({})
            return;
        }
        return res.json()
    })
    .then(json => {
        console.dir(json)
        sendResponse(json)
    })
    .catch(err => {
        console.error(err)
        sendResponse({})
    })
}

function fetchMargin(sendResponse, formData) {
    formData = "action=calculate&" + formData
    //"exchange[]=NFO&product[]=FUT&scrip[]=NIFTY23FEB&option_type[]=CE&strike_price[]=&qty[]=50&trade[]=sell"
    fetch("https://zerodha.com/margin-calculator/SPAN", {
    "headers": {
        "accept": "application/json, text/javascript, */*; q=0.01",
        "accept-language": "en-US,en;q=0.9",
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "sec-ch-ua": "\"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"108\", \"Google Chrome\";v=\"108\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "x-requested-with": "XMLHttpRequest"
    },
    "referrer": "https://zerodha.com/",
    "referrerPolicy": "origin",
    "body": formData,
    "method": "POST",
    "mode": "cors",
    "credentials": "include"
    })
    .then(res => {
        if(res.status!==200)
        {
            sendResponse({})
            return;
        }
        return res.json()
    })
    .then(json => {
        //console.dir(json)
        sendResponse(json)
    })
    .catch(err => {
        //console.error(err)
        sendResponse({})
    })
}

/*
chrome.webRequest.onBeforeSendHeaders.addListener(
    function(details) {
      details.requestHeaders.push({name: 'Referer', value:'http://localhost/referer'});
      return {requestHeaders: details.requestHeaders};
    },
    {urls: ["http://localhost/*"]},
    ["requestHeaders"]
  );
  */