if (window.self !== window.top) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.dir(request)
        if (request.type === 'OptionAllHistory') {
            fetchOpstraStandardDerivative(sendResponse, request.url)
            return true
        }
    })
    function fetchOpstraStandardDerivative(sendResponse, url) {
        fetch(url,
            {
                "headers": {
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"",
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": "\"Windows\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin"
                },
                "referrer": "https://www.nseindia.com/get-quotes/derivatives?symbol=NIFTY",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": null,
                "method": "GET",
                "mode": "cors",
                "credentials": "include"
            }).then(res => {
                if (res.status !== 200) {
                    sendResponse(undefined)
                }
                return res.json()
            }).then(json => {
                sendResponse(json)
            }).catch(function (err) {
                //console.error(err)
                sendResponse(undefined)
            });
    }
}
