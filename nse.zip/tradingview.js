if(window.self !== window.top) {
    setTimeout(()=>{
        try{
            document.querySelector('#header-toolbar-indicators>div>div').click()
            setTimeout(()=>{
                document.querySelector('div[title="Bollinger Bands"]').click()
                document.querySelector('div[title="Keltner Channels"]').click()
                document.querySelector('div[title="Hull Moving Average"]').click()
                document.querySelector('div[title="MACD"]').click()
                document.querySelector('div[title="SuperTrend"]').click()
                document.querySelector('div[title="Parabolic SAR"]').click()
                document.querySelector('div[title="Relative Strength Index"]').click()
                document.querySelector('div[title="MA Cross"]').click()
                document.querySelector('div[title="Directional Movement"]').click()
                setTimeout(()=>{
                    document.querySelector('.tv-dialog__close.js-dialog__close').click()
                    setTimeout(()=>{
                        document.querySelector('#header-toolbar-properties').click()
                        setTimeout(()=>{
                            document.querySelector('input[name="toggle-enabled"]').click()
                            setTimeout(()=>{
                                document.querySelector('span[class^="closeButton"]').click()
                            }, 100)
                        }, 1000)
                    }, 100)
                }, 100)
            }, 500)
        }catch(e){
        }
    }, 1000)

}