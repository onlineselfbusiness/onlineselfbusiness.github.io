
if(window.self !== window.top) {
    
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.dir(request)
        if(request.type === 'iChartSentiment') {
            fetchIchartSentiment(sendResponse, request.scriptName)
            return true
        } else if(request.type === 'iChartScreener') {
            fetchIchartScreenerEOD(sendResponse)
            return true
        }
    })

    function fetchIchartSentiment(sendResponse, scriptName) {
        fetch('https://main.icharts.in/jcharts/StockGlance_eod.php?symbol='+ scriptName+ '/sdf')
        .then(res => {
            if(res.status!==200)
            {
                sendResponse('')
            }
            return res.text()
        })
        .then(csv => {
            //console.dir(csv)
            sendResponse(csv)
        })
        .catch(err => {
            console.error(err)
            sendResponse('')
        })
    }

    function fetchIchartScreenerEOD(sendResponse) {
        fetch('https://main.icharts.in/includes/screener/EODScan.php?export=1')
        .then(res => {
            if(res.status!==200)
            {
                sendResponse('')
            }
            return res.text()
        })
        .then(csv => {
            //console.dir(csv)
            sendResponse(csv)
        })
        .catch(err => {
            console.error(err)
            sendResponse('')
        })
    }
}
