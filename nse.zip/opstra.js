// localStorage.setItem('test', {})
//if(!document.querySelector('.fa-sign-out-alt')) {
    //alert('Hey Please login to https://opstra.definedge.com')
    //window.open('https://opstra.definedge.com/')
//}
/*try {
    window.parent.location.href
} catch(e) {
    if(!document.querySelector('.fa-sign-out-alt')) {
        alert('Hey Please login to https://opstra.definedge.com')
        window.open('https://opstra.definedge.com/')
    }
}*/

if(window.self !== window.top) {
    
    /*if(!document.querySelector('.fa-sign-out-alt')) {
        alert('Hey Please login to https://opstra.definedge.com')
        window.open('https://opstra.definedge.com/')
    }*/

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.dir(request)
        if(request.type === 'fetchOpstraSD') {
            fetchOpstraStandardDerivative(sendResponse, request.scriptName)
            return true
        }
    })
    function fetchOpstraStandardDerivative(sendResponse, scriptNameWithExpiry) {
        fetch('https://opstra.definedge.com/api/free/strategybuilder/strikes/' + scriptNameWithExpiry, {
            "headers": {
              "accept": "application/json, text/plain, */*",
              "accept-language": "en-US,en;q=0.9",
              "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"",
              "sec-ch-ua-mobile": "?0",
              "sec-ch-ua-platform": "\"Windows\"",
              "sec-fetch-dest": "empty",
              "sec-fetch-mode": "cors",
              "sec-fetch-site": "same-origin"
            },
            "referrer": "https://opstra.definedge.com/strategy-builder",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": null,
            "method": "GET",
            "mode": "cors",
            "credentials": "include"
          })
        .then(res => {
            if(res.status!==200)
            {
                sendResponse({})
            }
            return res.json()
        })
        .then(json => {
            console.dir(json)
            sendResponse(json)
        })
        .catch(err => {
            console.error(err)
            sendResponse({})
        })
    }
}

