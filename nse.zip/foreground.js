let GlobalMarketTimings = [
    {country: 'Japan', exchange: 'Japan Exchange Group', index: 'Nikkei', openTime:'5 : 30 AM', closeTime: '11 : 30 AM'},
    {country: 'Australia', exchange: 'Australian Securities Exchange', index: 'S&P ASX', openTime:'5 : 30 AM', closeTime: '11 : 30 AM'},
    {country: 'South Korea', exchange: 'KRX Korean Exchange', index: 'Kospi', openTime:'5 : 30 AM', closeTime: '11 : 30 AM'},
    {country: 'Hong Kong', exchange: 'HKEX Hong Kong Exchange', index: 'Hang Seng', openTime:'6 : 45 AM', closeTime: '1 : 30 PM'},
    {country: 'China', exchange: 'Shanghai Stock Exchange & Shenzen stock Exchange', index: 'SSE', openTime:'7 : 00 AM', closeTime: '12 : 30 PM'},
    {country: 'India', exchange: 'NSE & BSE ', index: 'Nifty, Sensex', openTime:'9 : 15 AM', closeTime: '3 : 30 PM'},
    {country: 'Germany', exchange: 'Deutsche Börse AG', index: 'DAX', openTime:'12 : 30 PM', closeTime: '2 : 30 AM'},
    {country: 'UK', exchange: 'London Stock Exchange', index: 'FTSE', openTime:'1 : 30 PM', closeTime: '10 : 00 PM'},
    {country: 'USA', exchange: 'NYSE, NASDAQ', index: 'Dow, NASDAQ, S&P 500', openTime:'7 : 00 PM', closeTime: '1 : 30 AM'}
  ]
function dispatchChangeEvent(elementId, eleVal) {
    let e = new Event("change")
    let element = document.querySelector(elementId)
    if(eleVal) {
      try {
        element.value = eleVal
      }catch(e) {
        console.dir(elementId + ' not found')
       return
      }
    }
    element.dispatchEvent(e)
}
setTimeout(loadingActions, 100)
function loadingActions() {
    let optionChainReqId = document.querySelector('#optionChainReqId')
    optionChainReqId && optionChainReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'OptionChain',
                indexName: e.target.value
            }, response => {
                let json = JSON.parse(response)
                //console.dir(json)
                if(json.records) {
                    let optionChain = {
                        data: json.records.data,
                        timestamp: json.records.timestamp,
                        underlyingValue: json.records.underlyingValue
                    }
                    optionChain.fetchTime = new Date
                    let d = optionChain.data
                    let formattedData = {}
                    for (let i = 0; i < d.length; i++) {
                        let expiryDate = []
                        if (formattedData[d[i].expiryDate]) {
                            expiryDate = formattedData[d[i].expiryDate]
                        } else {
                            formattedData[d[i].expiryDate] = expiryDate
                        }
                        let strikePrice = d[i].strikePrice
                        expiryDate.push({ [strikePrice]: { 'PE': d[i]['PE'], 'CE': d[i]['CE'] } })
                    }
                    optionChain.data = formattedData
    
                    let e = new Event("change")
                    let element = document.querySelector('#optionChainResId')
                    sessionStorage.setItem('tempData', JSON.stringify(optionChain))
                    element.dispatchEvent(e)
                }
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Option Chain')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let worldMarketId = document.querySelector('#worldMarketId')
    worldMarketId && worldMarketId.addEventListener('change', (e)=>{
        try {
            chrome.runtime.sendMessage({
                type: 'WorldMarket'
            }, htmlArr => {
                updateWorldMarket(htmlArr[0].value)
                updateSGXNifty(htmlArr[1].value)
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded World Market')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let optionHistoryId = document.querySelector('#optionHistoryId')
    optionHistoryId && optionHistoryId.addEventListener('change', (e) => {
        try {
            let input = sessionStorage.getItem('optionHistoryInput')
            chrome.runtime.sendMessage({
                type: 'OptionHistory',
                data: JSON.parse(input)
            }, json => {
                sessionStorage.setItem('optionHistory', JSON.stringify(json))
                dispatchChangeEvent('#optionHistoryResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Option History')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let scriptHistoryId = document.querySelector('#scriptHistoryId')
    scriptHistoryId && scriptHistoryId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'ScriptHistory',
                scriptName: e.target.value
            }, jsonArr => {
                console.dir(jsonArr)
                let ScriptHistoryData = JSON.parse(localStorage.getItem('ScriptHistoryData'))
                for(let i=0; i<jsonArr.length; i++) {
                    if(jsonArr[i].value.data.length>0) {
                        if(jsonArr[i].value.name == 'NIFTY' || jsonArr[i].value.name == 'BANKNIFTY') {
                            ScriptHistoryData[jsonArr[i].value.name] = [...jsonArr[i].value.data, ...jsonArr[i+1].value.data]
                            i++
                        } else {
                            ScriptHistoryData[jsonArr[i].value.name] = jsonArr[i].value.data
                        }
                    }
                }
                localStorage.setItem('ScriptHistoryData', JSON.stringify(ScriptHistoryData))
                let DownloadTime = JSON.parse(localStorage.getItem('DownloadTime')) || {}
                DownloadTime['ScriptHistoryData'] = new Date().toLocaleString()
                localStorage.setItem('DownloadTime', JSON.stringify(DownloadTime))
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Script History')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })
     
    let etDatepickerReqId = document.querySelector('#etDatepickerReqId')
    etDatepickerReqId && etDatepickerReqId.addEventListener('change', (e) => {
        try {
            let tDate = new Date()
            tDate = tDate.toISOString().split('T')[0]
            if(tDate == e.target.value) {
                chrome.runtime.sendMessage({
                    type: 'ETDatepickerReq',
                    startDate: e.target.value
                }, jsonArr => {
                    sessionStorage.setItem('tempETDatepickerRes', JSON.stringify(jsonArr))
                    dispatchChangeEvent('#etDatepickerResId')
                    dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Result Calendar')
                })
            } else {
                chrome.runtime.sendMessage({
                    type: 'ETDatepickerDaysReq',
                    days: e.target.value
                }, jsonArr => {
                    var daysData = []
                    for(var i=0; i<jsonArr.length; i++) {
                        daysData.push({
                            eventDate: jsonArr[i].value.pageSummary.eventDate,
                            searchResult: jsonArr[i].value.searchResult
                        })
                    }
                    let etData = {
                        fetchDate: new Date().toISOString().split('T')[0],
                        data: daysData
                    }
                    localStorage.setItem('ETDatepickerDaysRes', JSON.stringify(etData))
                    //dispatchChangeEvent('#etDatepickerResId')
                    dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Result Calendar')
                })
            }
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })
    
    let mcResultCalendarReqId = document.querySelector('#mcResultCalendarReqId')
    mcResultCalendarReqId && mcResultCalendarReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'MoneyControlRCReq'
            }, html => {
                processMoneyControlRC(html)
                dispatchChangeEvent('#mcResultCalendarResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Result Calendar')
            })
        } catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })
    let maxPainStocksReqId = document.querySelector('#maxPainStocksReqId')
    maxPainStocksReqId && maxPainStocksReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'MaxPainReq'
            }, jsonArr => {
                localStorage.setItem('MaxPainList', JSON.stringify(jsonArr['resultData']))
                let DownloadTime = JSON.parse(localStorage.getItem('DownloadTime')) || {}
                DownloadTime['MaxPainList'] = new Date().toLocaleString()
                localStorage.setItem('DownloadTime', JSON.stringify(DownloadTime))
                dispatchChangeEvent('#maxPainStocksResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Max Pain')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let nifty50StocksReqId = document.querySelector('#nifty50StocksReqId')
    nifty50StocksReqId && nifty50StocksReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'Nifty50Stocks'
            }, jsonArr => {
                sessionStorage.setItem('Nifty50Stocks', JSON.stringify(jsonArr['resultData']))
                dispatchChangeEvent('#nifty50StocksResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Nifty 50 Stocks')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })
    
    let ocGraphReqId = document.querySelector('#ocGraphReqId')
    ocGraphReqId && ocGraphReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'OptionChainGraph',
                value: e.target.value
            }, jsonArr => {
                let seriesOptions = []
                seriesOptions[0] = {
                    name: jsonArr[0].value.name,
                    data: jsonArr[0].value.grapthData
                }
                seriesOptions[1] = {
                    name: jsonArr[1].value.name,
                    data: jsonArr[1].value.grapthData
                }
                sessionStorage.setItem('OptionChainGraph', JSON.stringify(seriesOptions))
                dispatchChangeEvent('#ocGraphResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Option Chain Graph')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let googleGraphReqId = document.querySelector('#googleGraphReqId')
    googleGraphReqId && googleGraphReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'GoogleGraph',
                value: e.target.value
            }, html => {
                html = optimizeGoogleChart(html)
                sessionStorage.setItem('GoogleGraph', html)
                dispatchChangeEvent('#googleGraphResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Google Graph')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let ichartScreenerReqId = document.querySelector('#ichartScreenerReqId')
    ichartScreenerReqId && ichartScreenerReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'iChartScreener'
            }, csv => {

                let dataArr = {}
                csv.replaceAll('"', '').replaceAll('\r', '').split('\n').forEach(r => {
                    let rArr = r.split(',')
                    dataArr[rArr[0]] = rArr.slice(1)
                })

                let ichartArr = {}
                Object.keys(dataArr).forEach(k => {
                    ichartArr[k] = dataArr[k].map(v => {
                        if(isNaN(v)) {
                            return v
                        } else {
                            return parseFloat(v)
                        }
                    })
                })

                localStorage.setItem('iChartScreener', JSON.stringify(ichartArr))
                dispatchChangeEvent('#ichartScreenerResId')
                let DownloadTime = JSON.parse(localStorage.getItem('DownloadTime')) || {}
                DownloadTime['iChartScreener'] = new Date().toLocaleString()
                localStorage.setItem('DownloadTime', JSON.stringify(DownloadTime))
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded ichart screener eod')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })
    
    let ichartSentimentReqId = document.querySelector('#ichartSentimentReqId')
    ichartSentimentReqId && ichartSentimentReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'iChartSentiment',
                scriptName: e.target.value
            }, html => {
                html = html && html.replaceAll('http://', 'https://') || ''
                sessionStorage.setItem('iChartSentiment', html)
                dispatchChangeEvent('#ichartSentimentResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded ichart sentiment')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let cashAndCarryReqId = document.querySelector('#cashAndCarryReqId')
    cashAndCarryReqId && cashAndCarryReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'CashAndCarry'
            }, html => {
                html = html.replaceAll('http://', 'https://')
                processCashAndCarry(html)
                dispatchChangeEvent('#cashAndCarryResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Cash & Carry')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })
    
    let opstraSDReqId = document.querySelector('#opstraSDReqId')
    opstraSDReqId && opstraSDReqId.addEventListener('change', (e) => {
        try {
            let v = e.target.value
            chrome.runtime.sendMessage({
                type: 'OpstraSD',
                scriptName: v.toUpperCase()
            }, json => {
                let OpstraSD = JSON.parse(localStorage.getItem('OpstraSD'))
                delete json['strikes']
                json['fetchTime'] = new Date
                OpstraSD[v] = json
                localStorage.setItem('OpstraSD', JSON.stringify(OpstraSD))
                dispatchChangeEvent('#opstraSDResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded Opstra SD')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let businesstodayReqId = document.querySelector('#businesstodayReqId')
    businesstodayReqId && businesstodayReqId.addEventListener('change', (e) => {
        try {
            chrome.runtime.sendMessage({
                type: 'businesstoday'
            }, html => {
                html = html && html.replaceAll('http://', 'https://') || ''
                sessionStorage.setItem('businesstoday', html)
                dispatchChangeEvent('#businesstodayResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded businesstoday market news')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    let priceApiReqId = document.querySelector('#priceApiReqId')
    priceApiReqId && priceApiReqId.addEventListener('change', (e) => {
        try {
            let v = e.target.value
            chrome.runtime.sendMessage({
                type: 'PriceApi',
                scriptName: v.toUpperCase()
            }, jsonArr => {
                //let PriceApi = JSON.parse(localStorage.getItem('PriceApi'))
                let ScriptHistoryData = JSON.parse(localStorage.getItem('ScriptHistoryData'))
                //json['fetchTime'] = new Date

                for(let i=0; i<jsonArr.length; i++) {
                    if(jsonArr[i].value.data) {
                        let json = jsonArr[i].value.data
                        let v = jsonArr[i].value.name
                        if(json['v'] && delete json['v']) {
                            let data = []
                            let tArr = json['t']
                            let oArr = json['o']
                            let hArr = json['h']
                            let lArr = json['l']
                            let cArr = json['c']
        
                            for(let i=0; i<tArr.length; i++) {
                                let d = []
                                let ds = new Date(parseInt(tArr[i] + '000')).toDateString().split(' ')
                                d.push(ds[2] + '-' + ds[1] + '-' + ds[3])
                                d.push(oArr[i])
                                d.push(hArr[i])
                                d.push(lArr[i])
                                d.push(cArr[i])
        
                                data.push(d)
                            }
                            console.dir(data)
                            ScriptHistoryData[v] = data.reverse()
                            //PriceApi[v] = json
                        }
                    }
                }
                localStorage.setItem('ScriptHistoryData', JSON.stringify(ScriptHistoryData))
                //localStorage.setItem('PriceApi', JSON.stringify(PriceApi))
                dispatchChangeEvent('#priceApiResId')
                dispatchChangeEvent('#messageStatusId', 'Successfully downloaded PriceApi')
            })
        }catch(e){
            dispatchChangeEvent('#messageStatusId', 'Error : ' + e.message)
        }
    })

    dispatchChangeEvent('#messageStatusId', 'Extension detected successfully, Enjoy :-)')
}
function replaceTags(start, end, data) {
    var s = data.indexOf(start);
    var e = data.indexOf(end);
    while(s > 0 && e > 0) {
        data = data.substr(0, s) + data.substr(e + end.length);
        s = data.indexOf(start);
        e = data.indexOf(end);
    }
    return data;
}
function getSubstring(start, end, data) {
    var s = data.indexOf(start);
    var e = data.indexOf(end);
    if(s>0 && e>0) {
        data = data.substring(s, e + end.length);
    }
    return data;
}
function updateWorldMarket(html) {
    let virtualDOM = document.implementation.createHTMLDocument('virtual');
    html = replaceTags('<!--', '-->', html)
    html = replaceTags('<script', '</script>', html)
    html = replaceTags('<style', '</style>', html)
    html = getSubstring('<body', '</body>', html)
    let htmlNode = jQuery.parseHTML(html, virtualDOM);
    let $html = $(htmlNode);

    let $tr = $html.find('.main-table.small.bold').find('tr');
    for(let i=0; i<$tr.length; i++) {
        if(i>12 && i<27) {
            $($tr[i]).remove();
        }
    }

    let $content = $html.find('.grid.col-940.centertext');
    $('#worldMarket').empty();
    $('#worldMarket').append($content);

    let symbolArr = $('#worldMarket tbody tr>td:nth-child(1)').toArray().splice(0, 12)
    symbolArr.forEach(td => {
        let s = (td.childNodes[1]).textContent
        td.childNodes[1].remove()
        let v = s.trim().replace('&', '').trim()
        $(td).append('<a target="_blank" href="https://www.google.com/search?q=' + v + '">' + s + '</a>')
    })
}
function updateSGXNifty(html) {
    let virtualDOM = document.implementation.createHTMLDocument('virtual');
    html = replaceTags('<!--', '-->', html)
    html = replaceTags('<script', '</script>', html)
    html = replaceTags('<style', '</style>', html)
    html = getSubstring('<body', '</body>', html)
    let htmlNode = jQuery.parseHTML(html, virtualDOM);
    let $html = $(htmlNode);
    let $div = $('<div><center><b>SGX Nifty</b></center></div>')
    $div.append($html.find('.main-meta').get(0))
    let $tables = $html.find('table.main-table')
    $div.append($tables.get(0))
    $div.append($tables.get(1))
    $div.append($tables.get(2))
    $('#sgxNifty').empty();
    $('#sgxNifty').append($div);

    let indexTimes = $(`<table class="main-table small bold"> <thead> 
    <tr> <td>Exchange</td> <td>Open Time</td> <td>Close Time</td> </tr> 
    </thead> 
    <tbody>
    <tr> 
    <td>Nikkei, S&P ASX</td> 
    <td>${new Date(new Date(new Date().toDateString()+' 09:00:00 GMT+9').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    <td>${new Date(new Date(new Date().toDateString()+' 15:00:00 GMT+9').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    </tr> 
    <tr> 
    <td>Hang Seng, Shanghai </td> 
    <td>${new Date(new Date(new Date().toDateString()+' 09:30:00 GMT+8').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    <td>${new Date(new Date(new Date().toDateString()+' 16:00:00 GMT+8').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    </tr>
    <tr> 
    <td>FTSE, CAC 40, DAX</td> 
    <td>${new Date(new Date(new Date().toDateString()+' 08:00:00 GMT+1').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    <td>${new Date(new Date(new Date().toDateString()+' 16:00:00 GMT+1').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    </tr>
    <tr> 
    <td>Dow,NASDAQ,S&P500</td> 
    <td>${new Date(new Date(new Date().toDateString()+' 09:30:00 GMT-4').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    <td>${new Date(new Date(new Date().toDateString()+' 16:00:00 GMT-4').toGMTString()).toLocaleTimeString().replaceAll(':00 ', ' ')}</td> 
    </tr>
    </tbody></table>`)
    $('#sgxNifty').append(indexTimes);
}
function optimizeGoogleChart(html) {
    let virtualDOM = document.implementation.createHTMLDocument('virtual');
    html = replaceTags('<!--', '-->', html)
    html = replaceTags('<script', '</script>', html)
    //html = replaceTags('<style', '</style>', html)
    html = getSubstring('<body', '</body>', html)
    let htmlNode = jQuery.parseHTML(html, virtualDOM);
    //let $chart = $(htmlNode).find("div#knowledge-finance-wholepage__entity-summary")
    //return $chart.parent().html()
    return $(htmlNode).find('g-card-section>div[jscontroller]').parent().html()
}
function processMoneyControlRC(html) {
    let virtualDOM = document.implementation.createHTMLDocument('virtual');
    html = replaceTags('<!--', '-->', html)
    html = replaceTags('<script', '</script>', html)
    html = replaceTags('<style', '</style>', html)
    html = getSubstring('<body', '</body>', html)
    let htmlNode = jQuery.parseHTML(html, virtualDOM);
    let $html = $(htmlNode).find('#tbl_box1').parent().html()
    if($html) {
        localStorage.setItem('AllResultCalendar', $html.replace(/\t+/g,'').replace(/href/g, ' target="_blank" href'))
    } else {
        localStorage.setItem('AllResultCalendar', '')
        return
    }
    
    let sArr = $(htmlNode).find('#tbl_box1  > tbody').find('tr').toArray()
    let mcArr = []
    sArr.forEach(tr => {
        let tdArr = $(tr).find('td').toArray()
        mcArr.push([
            $(tdArr[0]).find('a').html(), // stock name
            $(tdArr[0]).find('a').attr('href'), // stock href
            $(tdArr[1]).html(), // result date
            $(tdArr[4]).html(), // 52w high
            $(tdArr[5]).html() // 52w low
        ])
    })
    localStorage.setItem('AllResultCalendarArr', JSON.stringify(mcArr))
    let DownloadTime = JSON.parse(localStorage.getItem('DownloadTime')) || {}
    DownloadTime['AllResultCalendarArr'] = new Date().toLocaleString()
    localStorage.setItem('DownloadTime', JSON.stringify(DownloadTime))
}
function getIchartScreenEOD() {
}
function processCashAndCarry(html) {
    let virtualDOM = document.implementation.createHTMLDocument('virtual');
    html = replaceTags('<!--', '-->', html)
    html = replaceTags('<script', '</script>', html)
    html = replaceTags('<style', '</style>', html)
    html = getSubstring('<body', '</body>', html)
    let htmlNode = jQuery.parseHTML(html, virtualDOM);
    let sArr = $(htmlNode).find('#datatab_1').find('table').find('tr').toArray()
    let mcArr = []
    sArr.forEach(tr => {
        let tdArr = $(tr).find('td').toArray()
        let thArr = $(tr).find('th').toArray()
        mcArr.push([
            $(thArr[0]).find('a').html(), // stock name
            $(tdArr[0]).html(), // future price
            $(tdArr[1]).html(), // spot price
            $(tdArr[2]).html(), // basis
            $(tdArr[3]).html(), // basis per
            $(tdArr[4]).html(), // previous basis
            $(tdArr[5]).html(), // change
            $(tdArr[6]).html(), // lot size
        ])
    })
    console.dir(mcArr)
    localStorage.setItem('CashAndCarry', JSON.stringify(mcArr))
    let DownloadTime = JSON.parse(localStorage.getItem('DownloadTime')) || {}
    DownloadTime['CashAndCarry'] = new Date().toLocaleString()
    localStorage.setItem('DownloadTime', JSON.stringify(DownloadTime))
}