function downloadIndexScripts() {
    fetch("https://www.nseindia.com",
    {
        method: 'GET',
        cache: 'no-cache',
        mode: 'cors',
        headers: {
            'Referer': 'https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%2050',
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "*/*"
        },
        referrer: 'https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%2050',
    })
        .then(res => { return res.text() })
        .then(r => { 
            console.dir(r)
            
         });
}

$(() => {
    $('#downloadId').click((e)=> {
        downloadIndexScripts()
    })
})