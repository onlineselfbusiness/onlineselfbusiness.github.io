if (window.self !== window.top) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        //console.dir(request)
        if (request.type === 'OptionAllHistory') {
            //fetchOpstraStandardDerivative(sendResponse, request.url)
            downloadOptionAllHistoryWrapper(sendResponse, request.expiryDate, request.sprikePrices)
            return true
        }
    })

    function downloadOptionAllHistoryWrapper(sendResponse, expiryDate, strikePrices) {
        let promiseAll = new Promise(async(resolve, reject) => {
    
            let ed = expiryDate
            let to = new Date(ed)
            to = to.toLocaleDateString().split('/')
            to = (to[1].length == 1 ? '0' + to[1] : to[1]) + '-' + (to[0].length == 1 ? '0' + to[0] : to[0]) + '-' + to[2]

            //let tArr = to.toDateString().split(' ')
            //to = tArr[2] + '-' + tArr[1] + '-' + tArr[3]

            let from = new Date('01' + ed.substr(2))
            from.setMonth(from.getMonth() - 2)
            from.setDate(from.getDate() - 1)
            while (true) {
                if (from.toDateString().indexOf('Thu') > -1) {
                    break;
                }
                from.setDate(from.getDate() - 1)
            }

            //let fArr = from.toDateString().split(' ')
            //from = fArr[2] + '-' + fArr[1] + '-' + fArr[3]
            from = new Date(from)
            from = from.toLocaleDateString().split('/')
            from = (from[1].length == 1 ? '0' + from[1] : from[1]) + '-' + (from[0].length == 1 ? '0' + from[0] : from[0]) + '-' + from[2]
            let arr = strikePrices.split(',')
            let sPromises = []
            for(let i=0; i<arr.length; i++) {
                sPromises.push(optionAllHistoryForStrikePriceFromOldWebsite(expiryDate, arr[i], from, to, 'PE'))
                sPromises.push(optionAllHistoryForStrikePriceFromOldWebsite(expiryDate, arr[i], from, to, 'CE'))
            }
            let promiseAllRes = await Promise.allSettled(sPromises)
            sendResponse(promiseAllRes)
            resolve(promiseAllRes)
        })
        return promiseAll
    }

    function optionAllHistoryForStrikePriceFromOldWebsite(ed, sp, from, to, optionType) {
        //sp = sp.replace('.00','')
        sp = sp + '.00'
        let edArr = ed.split('-')
        let d = new Date(ed)
        let m = (d.getMonth() + 1) + ''
        let led = edArr[0] + '-' + ((m.length == 1) ? ('0' + m) : m ) + '-' + edArr[2]
        //ed = led
        let url = 'https://www.nseindia.com/api/historical/fo/derivatives?&from=' + from + '&to=' + to + '&optionType=' + optionType + '&strikePrice=' + sp + '&expiryDate=' + ed + '&instrumentType=OPTIDX&symbol=NIFTY'
        
        let promise = new Promise((resolve, reject) => {
            fetch(url,
                {
                    "headers": {
                        "accept": "*/*",
                        "accept-language": "en-US,en;q=0.9",
                        "sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"",
                        "sec-ch-ua-mobile": "?0",
                        "sec-ch-ua-platform": "\"Windows\"",
                        "sec-fetch-dest": "empty",
                        "sec-fetch-mode": "cors",
                        "sec-fetch-site": "same-origin"
                    },
                    "referrer": url,
                    "referrerPolicy": "strict-origin-when-cross-origin",
                    "body": null,
                    "method": "GET",
                    "mode": "cors",
                    "credentials": "include"
                }).then(res => {
                    if (res.status !== 200) {
                        throw new Error(res.status)
                    }
                    return res.text()
                }).then(html => {
                    console.dir(html)
                    //resolve({ed: ed, sp: sp, data: html, optionType: optionType})
                    resolve({ed: ed, sp: sp,  data: '', optionType: optionType})
                }).catch(function (err) {
                    resolve({ed: ed, sp: sp,  data: '', optionType: optionType})
                });
            });
        return promise
    }


    function fetchOpstraStandardDerivative(sendResponse, url) {
        fetch(url,
            {
                "headers": {
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-ch-ua": "\"Google Chrome\";v=\"105\", \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"105\"",
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": "\"Windows\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin"
                },
                "referrer": "https://www.nseindia.com/get-quotes/derivatives?symbol=NIFTY",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": null,
                "method": "GET",
                "mode": "cors",
                "credentials": "include"
            }).then(res => {
                if (res.status !== 200) {
                    sendResponse(undefined)
                }
                return res.json()
            }).then(json => {
                sendResponse(json)
            }).catch(function (err) {
                //console.error(err)
                sendResponse(undefined)
            });
    }
}
