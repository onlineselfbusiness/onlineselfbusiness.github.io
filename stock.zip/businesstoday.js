if(window.self !== window.top) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.dir(request)
        fetchMarketNews(sendResponse)
        return true
    })

    function fetchMarketNews(sendResponse, scriptName) {
        fetch('https://www.businesstoday.in/markets')
        .then(res => {
            if(res.status!==200)
            {
                sendResponse('')
            }
            return res.text()
        })
        .then(html => {
            console.dir(html)
            sendResponse(html)
        })
        .catch(err => {
            console.error(err)
            sendResponse('')
        })
    }
}
